# Telegram Bot System

## Overview

This is a 24/7 automated Telegram messaging bot system built with Python and the Telethon library. The bot continuously sends messages to multiple Telegram groups with built-in resilience features including auto-restart capabilities, graceful shutdown handling, and ban detection. The system is designed for continuous operation with minimal manual intervention.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Core Components

**Bot Engine (secure_telegram_bot.py)**
- Main bot logic using Telethon library for Telegram API interaction
- Implements message sending with retry logic and error handling
- Features flood wait detection and ban/restriction monitoring
- Supports graceful shutdown via signal handlers (SIGTERM, SIGINT)

**Auto-Restart Guardian (auto_restart.py)**
- Wrapper process that ensures the bot never stops running
- Automatically restarts the bot process if it crashes or exits
- Handles process management and maintains restart counters
- Supports clean shutdown when termination signals are received

**Session Management (setup_bot.py)**
- One-time setup utility for creating persistent Telegram sessions
- Handles initial authentication including 2FA support
- Generates string sessions for headless operation
- Securely manages verification codes and passwords

### Design Patterns

**Fault Tolerance**
- Multi-layer error handling with specific exception types (FloodWaitError, ban detection)
- Retry mechanisms with exponential backoff for failed operations
- Process-level auto-restart to recover from unexpected failures

**Signal Handling**
- Graceful shutdown implementation across all components
- Global shutdown flags for coordinated termination
- Signal propagation between guardian and bot processes

**Security Architecture**
- Environment variable-based credential management
- String session persistence for headless authentication
- Secure input handling for sensitive data (passwords, codes)

### Message Distribution Strategy

**Multi-Group Targeting**
- Rotates through predefined list of Telegram groups
- Implements group-specific ban detection and handling
- Maintains separate error states for each target group

## External Dependencies

**Telethon Library**
- Primary Telegram client library for Python
- Handles MTProto protocol communication
- Provides session management and authentication

**Telegram API**
- Requires API ID and hash from Telegram developer portal
- Uses phone number-based authentication
- Supports 2FA and verification code workflows

**Python Standard Library**
- asyncio for asynchronous operations
- signal for process signal handling
- subprocess for process management
- os/sys for environment and system interaction

**Target Telegram Groups**
- arayis_vakti
- trarayisiniz  
- kadinarabul
- turkiyearayis0

The system operates entirely through Telegram's official API without requiring additional databases or external services beyond the core Telegram infrastructure.