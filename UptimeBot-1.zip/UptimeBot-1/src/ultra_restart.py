#!/usr/bin/env python3
"""
Ultra-aggressive restart system for Free Replit accounts
This ensures the bot NEVER stops, even with Free plan limitations
"""

import subprocess
import sys
import time
import signal
import os
import threading
import requests
from http.server import HTTPServer, BaseHTTPRequestHandler
import socket

print("🛡️ ULTRA-RESTART GUARDIAN - MAXIMUM UPTIME")
print("="*60)

# Global shutdown flag
shutdown_requested = False
bot_process = None

def signal_handler(signum, frame):
    global shutdown_requested
    print(f"\n🚨 Signal {signum} received - graceful shutdown...")
    shutdown_requested = True
    if bot_process:
        try:
            bot_process.terminate()
        except:
            pass

signal.signal(signal.SIGTERM, signal_handler)
signal.signal(signal.SIGINT, signal_handler)

class UltraKeepAliveHandler(BaseHTTPRequestHandler):
    def do_GET(self):
        self.send_response(200)
        self.send_header('Content-type', 'text/html')
        self.end_headers()
        response = """
        <!DOCTYPE html>
        <html>
        <head>
            <title>🤖 ULTRA Telegram Bot</title>
            <meta http-equiv="refresh" content="25">
        </head>
        <body style="font-family: Arial; text-align: center; background: #000; color: #0f0;">
            <h1>🤖 ULTRA TELEGRAM BOT</h1>
            <p>✅ MAXIMUM UPTIME MODE</p>
            <p>🛡️ FREE PLAN PROTECTION</p>
            <p>🔄 Auto-refresh every 25 seconds</p>
            <script>
                setInterval(function() {
                    fetch(location.href).catch(e=>console.log('keep alive'));
                }, 15000);
            </script>
        </body>
        </html>
        """
        self.wfile.write(response.encode())
    def log_message(self, format, *args): pass

def start_ultra_server():
    """Start ultra keep-alive HTTP server"""
    try:
        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
            s.bind(('', 0))
            port = s.getsockname()[1]
        
        server = HTTPServer(('0.0.0.0', port), UltraKeepAliveHandler)
        print(f"🌐 Ultra keep-alive server on port {port}")
        server.serve_forever()
    except Exception as e:
        print(f"⚠️ Server error: {e}")

def ultra_ping():
    """Ultra-aggressive ping system"""
    while not shutdown_requested:
        try:
            # Self-ping
            repl_url = os.environ.get('REPL_URL', '')
            if repl_url:
                requests.get(repl_url, timeout=5)
                print("🏓 Ultra-ping successful")
        except:
            print("🏓 Ultra-ping (normal failure)")
        
        time.sleep(60)  # Ping every minute

def run_bot():
    """Run the bot with ultra protection"""
    global bot_process
    try:
        print("🚀 ULTRA-starting Telegram bot...")
        bot_process = subprocess.Popen([
            sys.executable, 
            'src/secure_telegram_bot.py'
        ])
        return bot_process.wait()
    except Exception as e:
        print(f"💥 Bot failed: {e}")
        return 1
    finally:
        bot_process = None

def main():
    """Main ultra-restart loop"""
    # Start ultra-protection services
    server_thread = threading.Thread(target=start_ultra_server, daemon=True)
    ping_thread = threading.Thread(target=ultra_ping, daemon=True)
    
    server_thread.start()
    ping_thread.start()
    
    restart_count = 0
    
    while not shutdown_requested:
        restart_count += 1
        print(f"\n🔄 ULTRA-RESTART #{restart_count}")
        
        exit_code = run_bot()
        
        if shutdown_requested:
            break
            
        if exit_code == 0:
            print("✅ Bot exited normally")
        else:
            print(f"❌ Bot crashed: {exit_code}")
        
        if not shutdown_requested:
            print("⏳ Ultra-restart in 2 seconds...")
            for i in range(2, 0, -1):
                if shutdown_requested:
                    break
                print(f"⏰ {i}...")
                time.sleep(1)
    
    print("👋 Ultra-guardian shutdown")

if __name__ == '__main__':
    try:
        main()
    except KeyboardInterrupt:
        print("\n🛑 ULTRA-STOPPED")
    except Exception as e:
        print(f"💥 CRITICAL ULTRA FAILURE: {e}")
        # Emergency restart
        subprocess.run([sys.executable, __file__])