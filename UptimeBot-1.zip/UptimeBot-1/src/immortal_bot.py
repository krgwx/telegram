#!/usr/bin/env python3
"""
İÖLÜMSÜZ TELEGRAM BOT - EN AGRESIF ÇÖZÜM
Bu bot ASLA durmaz, her koşulda çalışır!
"""

import asyncio
import os
import sys
import signal
import subprocess
import time
import threading
from telethon import TelegramClient
from telethon.errors import FloodWaitError

print("💀 İMORTAL TELEGRAM BOT - HİÇ DURMAZ! 💀")
print("="*50)

# Credentials
api_id = '27065413'
api_hash = 'fd0bec61df8c985830f2aaf804afff99'
phone = '+905448566871'
target_groups = ['arayis_vakti', 'trarayisiniz', 'kadinarabul', 'turkiyearayis0']

# Global flags
running = True
restart_count = 0

def emergency_restart():
    """ACİL DURUM YENİDEN BAŞLATMA"""
    try:
        print("🚨 ACİL DURUM! Script kendini yeniden başlatıyor...")
        subprocess.Popen([sys.executable, __file__])
        sys.exit(0)
    except:
        pass

def signal_handler(signum, frame):
    global running
    print(f"🚨 Signal {signum} - 3 saniye sonra yeniden başlayacak!")
    time.sleep(3)
    emergency_restart()

signal.signal(signal.SIGTERM, signal_handler)
signal.signal(signal.SIGINT, signal_handler)

async def send_message_immortal(client, group, message):
    """ÖLÜMSÜZ MESAJ GÖNDERME"""
    for attempt in range(5):  # 5 deneme
        try:
            await client.send_message(group, message)
            return True
        except FloodWaitError as e:
            print(f"⏳ FloodWait {e.seconds}s - bekliyor...")
            await asyncio.sleep(e.seconds + 2)
        except Exception as e:
            if 'banned' in str(e).lower() or 'restricted' in str(e).lower():
                print(f"🚫 {group} banned")
                return False
            print(f"❌ Hata {attempt+1}: {type(e).__name__}")
            await asyncio.sleep(3)
    return False

async def immortal_cycle():
    """ÖLÜMSÜZ ÇEVRIM"""
    global restart_count
    restart_count += 1
    
    print(f"🔄 BAŞLATMA #{restart_count}")
    print(f"📡 Hedef gruplar: {', '.join(target_groups)}")
    
    client = None
    try:
        # Session oluştur - doğrudan session ismiyle
        client = TelegramClient('immortal_session', api_id, api_hash)
        
        await client.connect()
        
        if not await client.is_user_authorized():
            print("❌ Session invalid - otomatik auth başlatılıyor...")
            try:
                # Otomatik auth deneme
                await client.send_code_request(phone)
                print("📲 Telefona doğrulama kodu gönderildi")
                print("⚠️  Manuel doğrulama gerekli - bot'u durdurarak kodu giriniz")
                return False
            except Exception as auth_error:
                print(f"🚫 Auth hatası: {auth_error}")
                return False
        
        print("✅ BAĞLANDI!")
        
        cycle = 0
        banned = set()
        
        while running:
            cycle += 1
            print(f"\n🔄 ÇEVRİM #{cycle}")
            
            available = [g for g in target_groups if g not in banned]
            if not available:
                banned.clear()
                available = target_groups.copy()
            
            # 4 mesaj gönder
            for msg_num in range(1, 5):
                if not running: break
                
                message = 'Şov için müsaaitiimmmm ♥️'
                
                for group in available:
                    if not running: break
                    
                    success = await send_message_immortal(client, group, message)
                    if success:
                        print(f"✅ {msg_num}/4 → {group}")
                    else:
                        print(f"🚫 {msg_num}/4 → {group} (banned)")
                        banned.add(group)
                    
                    await asyncio.sleep(1)  # Kısa bekleme
                
                # Mesajlar arası bekleme - 4 saniye
                if msg_num < 4 and running:
                    for i in range(4, 0, -1):
                        if not running: break
                        print(f"⏳ Sonraki mesaja {i}s...")
                        await asyncio.sleep(1)
            
            # Çevrim arası bekleme - 15 saniye
            if running:
                for i in range(15, 0, -1):
                    if not running: break
                    if i % 5 == 0:  # Her 5 saniyede bir göster
                        print(f"⏳ Sonraki çevrime {i}s...")
                    await asyncio.sleep(1)
                    
    except Exception as e:
        print(f"💥 HATA: {type(e).__name__}")
        return False
    
    finally:
        if client:
            try:
                await client.disconnect()
                print("🔌 Bağlantı kesildi")
            except:
                pass
    
    return True

def restart_guardian():
    """YENİDEN BAŞLATMA KORUYUCUSU"""
    print("🛡️ Yeniden başlatma koruyucusu aktif")
    
    while True:
        try:
            print("🔥 IMMORTAL BOT BAŞLIYOR...")
            # Bot çalıştır
            result = asyncio.run(immortal_cycle())
            
            if not running:
                print("👋 Temiz çıkış")
                break
            
            print("💥 Bot durdu - 3 saniyede yeniden başlatılıyor...")
            time.sleep(3)
            
        except KeyboardInterrupt:
            print("\n🛑 DURDURULDU")
            break
        except Exception as e:
            print(f"💥 KRİTİK HATA: {e}")
            print("🔄 ACİL YENİDEN BAŞLATMA...")
            time.sleep(2)

# EMERGENCY BACKUP THREAD
def emergency_backup():
    """ACİL DURUM YEDEK SİSTEMİ"""
    while True:
        time.sleep(300)  # 5 dakikada bir kontrol
        # Eğer başka bir yöntemle bot kontrol edilebilir, buraya ekle
        print("🆘 Emergency backup check...")

if __name__ == '__main__':
    try:
        # Emergency backup thread başlat
        backup_thread = threading.Thread(target=emergency_backup, daemon=True)
        backup_thread.start()
        
        # Ana guardian'ı başlat
        restart_guardian()
        
    except Exception as e:
        print(f"💥 TOTAL SYSTEM FAILURE: {e}")
        emergency_restart()