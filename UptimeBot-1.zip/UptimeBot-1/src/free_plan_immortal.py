#!/usr/bin/env python3
"""
FREE PLAN İÇİN UPTIME GARANTILI IMMORTAL BOT
HTTP server + Bot kombinasyonu
"""

import asyncio
import threading
import time
import signal
import os
from http.server import HTTPServer, BaseHTTPRequestHandler
from telethon import TelegramClient
from telethon.errors import FloodWaitError
import subprocess

# arkaplanda welcome servisini başlat (aynı klasörde)
p = subprocess.Popen(["python3", "welcome_service.py"])
# eğer gerektiğinde kill etmek istersen: p.terminate()


print("🆓 FREE PLAN IMMORTAL BOT SISTEMI")
print("="*50)

# Credentials
api_id = '27065413'
api_hash = 'fd0bec61df8c985830f2aaf804afff99'
phone = '+905448566871'
target_groups = ['arayis_vakti', 'trarayisiniz', 'kadinarabul', 'turkiyearayis0']

# Global flags
running = True
bot_active = False
last_message_time = time.time()

class UptimeHandler(BaseHTTPRequestHandler):
    """Uptime için HTTP handler"""
    
    def do_GET(self):
        global bot_active, last_message_time
        
        try:
            self.send_response(200)
            self.send_header('Content-type', 'text/html')
            self.end_headers()
            
            uptime = time.time() - start_time
            hours = int(uptime // 3600)
            minutes = int((uptime % 3600) // 60)
            
            status = "🟢 ACTIVE" if bot_active else "🟡 WAITING"
            last_msg = int(time.time() - last_message_time)
            
            html = f"""
            <!DOCTYPE html>
            <html>
            <head>
                <title>IMMORTAL BOT STATUS</title>
                <meta http-equiv="refresh" content="30">
            </head>
            <body style="background:#0a0a0a;color:#00ff00;font-family:monospace;padding:20px;">
                <h1>🚀 IMMORTAL TELEGRAM BOT</h1>
                <h2>Status: {status}</h2>
                <p>📊 Uptime: {hours}h {minutes}m</p>
                <p>📱 Groups: {len(target_groups)}</p>
                <p>⏰ Last message: {last_msg}s ago</p>
                <p>🕒 {time.strftime('%Y-%m-%d %H:%M:%S')}</p>
                <hr>
                <p>💡 Bot is running on FREE PLAN with external uptime monitoring</p>
                <p>🔄 Auto-refresh every 30 seconds</p>
            </body>
            </html>
            """
            
            self.wfile.write(html.encode())
            print(f"📡 Uptime check: {self.client_address[0]}")
            
        except Exception as e:
            print(f"❌ HTTP error: {e}")
    
    def log_message(self, format, *args):
        pass

def signal_handler(signum, frame):
    global running
    print(f"🛑 Signal {signum} - Temiz çıkış...")
    running = False

signal.signal(signal.SIGTERM, signal_handler)
signal.signal(signal.SIGINT, signal_handler)

async def send_message_safe(client, group, message):
    """Güvenli mesaj gönderme"""
    global last_message_time
    
    try:
        await client.send_message(group, message)
        last_message_time = time.time()
        return True
    except FloodWaitError as e:
        print(f"⏳ FloodWait {e.seconds}s - bekliyor...")
        await asyncio.sleep(e.seconds + 2)
        return False
    except Exception as e:
        if 'banned' in str(e).lower() or 'restricted' in str(e).lower():
            print(f"🚫 {group} banned")
        else:
            print(f"❌ Hata: {type(e).__name__}")
        return False

async def bot_cycle():
    """Ana bot döngüsü"""
    global bot_active, running
    
    client = TelegramClient('immortal_session', api_id, api_hash)
    
    try:
        await client.connect()
        
        if not await client.is_user_authorized():
            print("❌ Session geçersiz!")
            bot_active = False
            return False
        
        print("✅ Bot aktif!")
        bot_active = True
        
        cycle = 0
        banned = set()
        
        while running:
            cycle += 1
            print(f"\n🔄 Çevrim #{cycle}")
            
            available = [g for g in target_groups if g not in banned]
            if not available:
                banned.clear()
                available = target_groups.copy()
            
            # Mesaj gönder
            for msg_num in range(1, 5):
                if not running: break
                
                message = '💘 SELAM BEN SALİHA ⭐️\n⭐️ GÖRÜNTÜLÜ ŞOV İÇİN MÜSAİTİM AŞKLARIM 🫦'
                
                for group in available:
                    if not running: break
                    
                    success = await send_message_safe(client, group, message)
                    if success:
                        print(f"✅ {msg_num}/4 → {group}")
                    else:
                        print(f"🚫 {msg_num}/4 → {group}")
                        banned.add(group)
                    
                    await asyncio.sleep(1)
                
                # Mesajlar arası bekleme
                if msg_num < 4 and running:
                    for i in range(4, 0, -1):
                        if not running: break
                        await asyncio.sleep(1)
            
            # Çevrim arası bekleme
            if running:
                for i in range(15, 0, -1):
                    if not running: break
                    if i % 5 == 0:
                        print(f"⏳ Sonraki çevrime {i}s...")
                    await asyncio.sleep(1)
                    
    except Exception as e:
        print(f"💥 Bot hatası: {type(e).__name__}")
        bot_active = False
        return False
    finally:
        try:
            await client.disconnect()
        except:
            pass
        bot_active = False
    
    return True

def run_http_server():
    """HTTP server'ı çalıştır"""
    try:
        server = HTTPServer(('0.0.0.0', 5000), UptimeHandler)
        print("🌐 HTTP Server başlatıldı: http://0.0.0.0:5000")
        print("📡 External uptime servisleri bu URL'yi ping'leyebilir!")
        server.serve_forever()
    except Exception as e:
        print(f"💥 HTTP Server hatası: {e}")
        time.sleep(5)
        if running:
            run_http_server()

def run_bot():
    """Bot'u çalıştır"""
    while running:
        try:
            print("🤖 Bot başlatılıyor...")
            asyncio.run(bot_cycle())
            
            if not running:
                break
                
            print("🔄 3 saniyede yeniden başlatılıyor...")
            time.sleep(3)
            
        except Exception as e:
            print(f"💥 Bot kritik hatası: {e}")
            time.sleep(5)

# Başlangıç zamanı
start_time = time.time()

if __name__ == '__main__':
    try:
        print("🚀 FREE PLAN UPTIME SİSTEMİ BAŞLIYOR...")
        print("📡 HTTP Server + Telegram Bot")
        print("="*50)
        
        # HTTP server thread'i başlat
        server_thread = threading.Thread(target=run_http_server, daemon=True)
        server_thread.start()
        
        # Bot thread'i başlat
        bot_thread = threading.Thread(target=run_bot, daemon=True)
        bot_thread.start()
        
        print("✅ Sistem aktif!")
        print("🌐 Status: http://localhost:5000")
        print("💡 External uptime servisleri için URL'yi kullanın")
        
        # Ana thread'i canlı tut
        while running:
            time.sleep(10)
        
    except KeyboardInterrupt:
        print("\n🛑 Sistem durduruldu")
        running = False
    except Exception as e:
        print(f"💥 Sistem hatası: {e}")
    finally:
        print("👋 Çıkış yapılıyor...")