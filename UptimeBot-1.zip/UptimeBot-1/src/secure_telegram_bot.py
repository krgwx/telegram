import asyncio
import os
import sys
import signal
import getpass
from telethon import TelegramClient
from telethon.sessions import StringSession
from telethon.errors import FloodWaitError
import time
from keep_alive import run_keep_alive
import json
from telethon import events, errors
import subprocess

# arkaplanda welcome servisini başlat (aynı klasörde)
p = subprocess.Popen(["python3", "welcome_service.py"])
# eğer gerektiğinde kill etmek istersen: p.terminate()


print("🤖 SECURE TELEGRAM BOT - 24/7 VERSION (FREE PLAN)")
print("="*55)


# Start keep-alive server for Free Replit account
run_keep_alive()

# Get credentials from environment variables (secure)
api_id = os.getenv('TELEGRAM_API_ID', '27065413')
api_hash = os.getenv('TELEGRAM_API_HASH', 'fd0bec61df8c985830f2aaf804afff99')
phone = os.getenv('TELEGRAM_PHONE', '+905448566871')
session_string = os.getenv('TELEGRAM_SESSION', '')

# Target groups - will rotate through all
target_groups = ['arayis_vakti', 'trarayisiniz', 'kadinarabul', 'turkiyearayis0']

async def send_message_safe(client, group, message):
    """Safely send message with retries and proper error handling"""
    for attempt in range(3):
        try:
            await client.send_message(group, message)
            return True, None
        except FloodWaitError as e:
            print(f"⚠️ FloodWait {e.seconds}s for {group} - backing off...")
            await asyncio.sleep(e.seconds + 1)
            return False, "flood_wait"
        except Exception as e:
            error_msg = str(e).lower()
            # Check for ban/restriction indicators
            if any(keyword in error_msg for keyword in ['banned', 'restricted', 'forbidden', 'kicked', 'left']):
                print(f"🚫 BANNED/RESTRICTED from {group}: {type(e).__name__}")
                return False, "banned"
            
            print(f"Send attempt {attempt+1} to {group} failed: {type(e).__name__}")
            if attempt < 2:
                await asyncio.sleep(5)
    return False, "failed"

# Global shutdown flag
shutdown_flag = False

def signal_handler(signum, frame):
    global shutdown_flag
    print(f"\n🚨 Signal {signum} received - scheduling graceful shutdown...")
    shutdown_flag = True

# Register signal handlers
signal.signal(signal.SIGTERM, signal_handler)
signal.signal(signal.SIGINT, signal_handler)

async def main():
    global shutdown_flag
    restart_count = 0
    
    print("🛡️ Signal handlers registered")
    
    # INFINITE RESTART LOOP - NEVER STOPS
    while not shutdown_flag:
        restart_count += 1
        print(f"\n🚀 BOT START #{restart_count}")
        print(f"📡 Target groups: {', '.join(target_groups)}")
        
        client = None
        try:
            # Create client with session
            if session_string:
                print("🔑 Using StringSession from environment...")
                client = TelegramClient(StringSession(session_string), api_id, api_hash)
            elif os.path.exists('src/session_name.session'):
                print("🔑 Using existing session file...")
                client = TelegramClient('src/session_name', api_id, api_hash)
            else:
                print("🔑 Creating new session...")
                client = TelegramClient('src/bot_session', api_id, api_hash)
            
            print("🔌 Connecting...")
            await client.connect()
            
            # Check if we're already authorized
            if not await client.is_user_authorized():
                print("❌ Session invalid or missing - manual intervention required")
                print("⚠️ Bot cannot run in 24/7 mode without valid session")
                print("💡 Run setup once manually to create session")
                break
            
            print("✅ CONNECTED!")
            
            cycle = 0
            banned_groups = set()  # Track banned groups
            
            # INFINITE MESSAGE LOOP
            while not shutdown_flag:
                cycle += 1
                print(f"\n🔄 CYCLE #{cycle}")
                
                # Get available groups (not banned)
                available_groups = [g for g in target_groups if g not in banned_groups]
                
                if not available_groups:
                    print("⚠️ All groups banned! Clearing ban list and retrying...")
                    banned_groups.clear()  # Reset ban list, maybe some bans were temporary
                    available_groups = target_groups.copy()
                
                print(f"📋 Available groups: {len(available_groups)}/{len(target_groups)}")
                if banned_groups:
                    print(f"🚫 Banned groups: {', '.join(banned_groups)}")
                
                # Send 4 messages to each available group
                for i in range(1, 5):
                    if shutdown_flag:
                        break
                    
                    message = 'Şov için müsaaitiimmmm ♥️'
                    
                    # Send to all available groups
                    for group in available_groups:
                        if shutdown_flag:
                            break
                            
                        success, error_type = await send_message_safe(client, group, message)
                        
                        if success:
                            print(f"✅ {i}/4 → {group}")
                        elif error_type == "banned":
                            print(f"🚫 {i}/4 → {group} (BANNED - removing from rotation)")
                            banned_groups.add(group)
                        elif error_type == "flood_wait":
                            print(f"⏳ {i}/4 → {group} (FLOOD WAIT - will retry next cycle)")
                        else:
                            print(f"❌ {i}/4 → {group} (FAILED)")
                        
                        # Small delay between groups
                        if not shutdown_flag:
                            await asyncio.sleep(2)
                    
                    # Wait between message rounds
                    if i < 4 and not shutdown_flag:
                        print(f"⏳ Wait 4s before next message...")
                        for _ in range(4):
                            if shutdown_flag:
                                break
                            await asyncio.sleep(1)
                
                # Wait before next cycle
                if not shutdown_flag:
                    print("⏳ Wait 15s before next cycle...")
                    for _ in range(15):
                        if shutdown_flag:
                            break
                        await asyncio.sleep(1)
                
        except (KeyboardInterrupt, SystemExit, asyncio.CancelledError):
            print("🛑 Graceful shutdown requested")
            shutdown_flag = True
            
        except Exception as e:
            print(f"💥 ERROR: {type(e).__name__}")
            print(f"💥 Details: {str(e)[:100]}...")  # Don't log full error details
            
        finally:
            # Always cleanup
            if client:
                try:
                    await client.disconnect()
                    print("🔌 Disconnected")
                except Exception:
                    pass
            
            if not shutdown_flag:
                print("🔄 AUTO-RESTART in 5s...")
                for i in range(5, 0, -1):
                    print(f"⏰ Restarting in {i} seconds...")
                    await asyncio.sleep(1)
    
    print("👋 Clean shutdown completed")

if __name__ == '__main__':
    try:
        asyncio.run(main())
    except KeyboardInterrupt:
        print("🛑 STOPPED")
    except Exception as e:
        print(f"💥 CRITICAL: {type(e).__name__}")
        print("🔄 RESTARTING...")
        # Even if asyncio.run fails, restart the script
        import subprocess
        subprocess.run([sys.executable, __file__])




# -------------- WELCOME VOICE INTEGRATION --------------


REPLIED_FILE = "replied.json"
WELCOME_VOICE = "sesim.ogg"
WELCOME_TEXT = "Selam! Mesajını aldım, kısa sürede döneceğim."

# replied users set
try:
    with open(REPLIED_FILE, 'r') as f:
        replied_users = set(json.load(f))
except Exception:
    replied_users = set()

async def send_welcome(user_id):
    if str(user_id) in replied_users:
        return
    try:
        if os.path.isfile(WELCOME_VOICE):
            try:
                await client.send_file(user_id, WELCOME_VOICE, voice_note=True)
                print(f"✅ Ses gönderildi: {user_id}")
            except (errors.FloodWaitError, errors.RPCError) as e:
                print(f"⚠️ Flood/RPC hatası, bekle: {e}")
                await asyncio.sleep(getattr(e, "seconds", 10)+1)
                await client.send_message(user_id, WELCOME_TEXT)
            except Exception:
                await client.send_message(user_id, WELCOME_TEXT)
        else:
            await client.send_message(user_id, WELCOME_TEXT)

        # kaydet
        replied_users.add(str(user_id))
        with open(REPLIED_FILE, 'w') as f:
            json.dump(list(replied_users), f)
    except Exception as e:
        print("❌ Welcome PM error:", e)

# EVENT HANDLER (client start sonrası)
@client.on(events.NewMessage(incoming=True))
async def welcome_pm_handler(event):
    if event.is_private:
        sender = await event.get_sender()
        if sender and await client.is_user_authorized():
            await send_welcome(sender.id)