# welcome_service.py
import asyncio
import os
import json
import time
from telethon import TelegramClient, events, errors
from telethon.sessions import StringSession

# --------- CONFIG (doldurulmuş) ----------
API_ID = 27065413
API_HASH = "fd0bec61df8c985830f2aaf804afff99"
PHONE = "+905448566871"   # senin numara
SESSION_STRING = ""       # opsiyonel; yoksa 'session' dosyası oluşur

WELCOME_VOICE = "sesim.mp3"            # klasörde olmalı (opus/ogg en iyi)
WELCOME_TEXT = "Dekont bekliyorum aşkım"
REPLIED_FILE = "welcome_replied.json"  # hangi kullanıcıya gönderildiğini tutar
# -----------------------------------------

# client oluştur
if SESSION_STRING:
    client = TelegramClient(StringSession(SESSION_STRING), API_ID, API_HASH)
else:
    client = TelegramClient('session', API_ID, API_HASH)

# replied yükle
def load_replied():
    try:
        with open(REPLIED_FILE, 'r') as f:
            data = json.load(f)
            return set(data if isinstance(data, list) else [])
    except Exception:
        return set()

def save_replied(s):
    try:
        with open(REPLIED_FILE, 'w') as f:
            json.dump(list(s), f)
    except Exception as e:
        print("Replied save error:", e)

replied = load_replied()

async def send_welcome(user_id):
    sid = str(user_id)
    if sid in replied:
        return
    try:
        if os.path.isfile(WELCOME_VOICE):
            try:
                # voice_note=True ile ogg/opus ise 'ses balonu' olarak gider
                await client.send_file(user_id, WELCOME_VOICE, voice_note=True)
                print(f"[{time.ctime()}] Sent voice to {user_id}")
            except (errors.FloodWaitError) as fw:
                wait = int(getattr(fw, "seconds", 60))
                print(f"[{time.ctime()}] FloodWait {wait}s while sending to {user_id}")
                await asyncio.sleep(wait + 2)
                # dene fallback olarak text
                await client.send_message(user_id, WELCOME_TEXT)
            except Exception as e:
                print(f"[{time.ctime()}] Voice send failed for {user_id}: {e}")
                await client.send_message(user_id, WELCOME_TEXT)
        else:
            await client.send_message(user_id, WELCOME_TEXT)
            print(f"[{time.ctime()}] No voice file -> sent text to {user_id}")

        # kaydet
        replied.add(sid)
        save_replied(replied)

    except Exception as e:
        print(f"[{time.ctime()}] send_welcome exception: {e}")

# event handler - private mesajlar
@client.on(events.NewMessage(incoming=True))
async def pm_handler(event):
    try:
        if not event.is_private:
            return
        sender = await event.get_sender()
        if not sender:
            return
        # authorized olduğundan emin ol
        if not await client.is_user_authorized():
            print("Client not authorized yet.")
            return
        await send_welcome(sender.id)
    except Exception as e:
        print("pm_handler error:", e)

async def main():
    # başlat
    await client.start(phone=PHONE)
    print(f"[{time.ctime()}] Welcome service started. authorized={await client.is_user_authorized()}")
    if not await client.is_user_authorized():
        print("Session not authorized. Run once locally to create session.")
        return
    # sonsuza kadar dinle
    await client.run_until_disconnected()

if __name__ == "__main__":
    try:
        asyncio.run(main())
    except KeyboardInterrupt:
        print("Welcome service stopped by user.")