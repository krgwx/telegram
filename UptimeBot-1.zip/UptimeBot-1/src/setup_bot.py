#!/usr/bin/env python3
"""
One-time setup script for Telegram bot
Creates a persistent session for 24/7 operation
"""

import asyncio
import os
import getpass
from telethon import TelegramClient
from telethon.sessions import StringSession

print("🔧 TELEGRAM BOT SETUP")
print("="*30)

# Get credentials from environment or prompt
api_id = os.getenv('TELEGRAM_API_ID', '27065413')
api_hash = os.getenv('TELEGRAM_API_HASH', 'fd0bec61df8c985830f2aaf804afff99') 
phone = os.getenv('TELEGRAM_PHONE', '+905448566871')

async def setup_session():
    """Create a new session for the bot"""
    print(f"📱 Setting up session for: {phone}")
    
    # Create client with string session
    client = TelegramClient(StringSession(), api_id, api_hash)
    
    try:
        await client.connect()
        
        if not await client.is_user_authorized():
            print("📲 Sending verification code...")
            await client.send_code_request(phone)
            
            # Get verification code securely
            code = input("📋 Enter verification code: ").strip()
            
            try:
                await client.sign_in(phone, code)
            except Exception as e:
                if "two-step verification" in str(e).lower():
                    # 2FA required
                    password = getpass.getpass("🔐 Enter 2FA password: ")
                    await client.sign_in(password=password)
                else:
                    raise
        
        print("✅ Successfully authenticated!")
        
        # Get session string
        session_string = client.session.save()
        print(f"\n🔑 Session created successfully!")
        print("\n💡 Add this to your environment variables:")
        print(f"TELEGRAM_SESSION={session_string}")
        
        # Save to file as backup
        with open('src/session_backup.txt', 'w') as f:
            f.write(session_string)
        print("\n💾 Session also saved to: src/session_backup.txt")
        
        return session_string
        
    finally:
        await client.disconnect()

async def main():
    """Main setup function"""
    try:
        session = await setup_session()
        print("\n🎉 Setup complete! Your bot is ready for 24/7 operation.")
        print("\n⚠️ Keep your session string secure - it gives full access to your account!")
        print("\n🚀 Now you can run the secure bot with the saved session.")
        
    except KeyboardInterrupt:
        print("\n🛑 Setup cancelled")
    except Exception as e:
        print(f"\n💥 Setup failed: {e}")

if __name__ == '__main__':
    asyncio.run(main())