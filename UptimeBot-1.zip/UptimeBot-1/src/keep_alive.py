#!/usr/bin/env python3
"""
Keep-alive HTTP server for Free Replit accounts
Prevents workspace from sleeping by serving HTTP requests
"""

from http.server import HTTPServer, BaseHTTPRequestHandler
import threading
import time
import socket

class KeepAliveHandler(BaseHTTPRequestHandler):
    def do_GET(self):
        self.send_response(200)
        self.send_header('Content-type', 'text/html')
        self.end_headers()
        
        response = """
        <!DOCTYPE html>
        <html>
        <head>
            <title>🤖 Telegram Bot - Always Alive</title>
            <meta http-equiv="refresh" content="30">
        </head>
        <body style="font-family: Arial; text-align: center; background: #1a1a1a; color: #00ff00;">
            <h1>🤖 Telegram Bot Status</h1>
            <p>✅ Bot is RUNNING</p>
            <p>🔄 Keep-alive service ACTIVE</p>
            <p>⏰ Auto-refresh every 30 seconds</p>
            <p style="color: #888;">Free Replit workspace protection enabled</p>
        </body>
        </html>
        """
        self.wfile.write(response.encode())
    
    def log_message(self, format, *args):
        # Suppress HTTP server logs
        pass

def find_free_port():
    """Find a free port to bind the server"""
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
        s.bind(('', 0))
        s.listen(1)
        port = s.getsockname()[1]
    return port

def start_keep_alive_server():
    """Start HTTP server to keep workspace alive"""
    try:
        port = find_free_port()
        server = HTTPServer(('0.0.0.0', port), KeepAliveHandler)
        print(f"🌐 Keep-alive server started on port {port}")
        server.serve_forever()
    except Exception as e:
        print(f"⚠️ Keep-alive server failed: {e}")

def run_keep_alive():
    """Run keep-alive server in background thread"""
    thread = threading.Thread(target=start_keep_alive_server, daemon=True)
    thread.start()
    print("🛡️ Keep-alive protection activated")
    return thread