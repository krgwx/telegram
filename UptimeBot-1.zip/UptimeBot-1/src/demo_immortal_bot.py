#!/usr/bin/env python3
"""
İÖLÜMSÜZ TELEGRAM BOT - DEMO VERSİYONU
Bu version authentication bekleme modunda çalışır
"""

import asyncio
import os
import signal
import time
from telethon import TelegramClient

print("💀 İMORTAL TELEGRAM BOT - DEMO MOD 💀")
print("="*50)

# Credentials
api_id = '27065413'
api_hash = 'fd0bec61df8c985830f2aaf804afff99'
phone = '+905448566871'
target_groups = ['arayis_vakti', 'trarayisiniz', 'kadinarabul', 'turkiyearayis0']

# Global flags
running = True
restart_count = 0

def signal_handler(signum, frame):
    global running
    print(f"🛑 Signal {signum} - Temiz çıkış yapılıyor...")
    running = False

signal.signal(signal.SIGTERM, signal_handler)
signal.signal(signal.SIGINT, signal_handler)

async def check_auth_status():
    """Authentication durumunu kontrol et"""
    try:
        client = TelegramClient('immortal_session', api_id, api_hash)
        await client.connect()
        
        if await client.is_user_authorized():
            print("✅ Session doğrulanmış - Bot aktif modda!")
            await client.disconnect()
            return True
        else:
            print("❌ Session doğrulanmamış - Bekleme modunda")
            await client.disconnect()
            return False
    except Exception as e:
        print(f"🔍 Auth kontrol hatası: {type(e).__name__}")
        return False

async def send_message_immortal(client, group, message):
    """ÖLÜMSÜZ MESAJ GÖNDERME"""
    try:
        await client.send_message(group, message)
        return True
    except Exception as e:
        if 'banned' in str(e).lower() or 'restricted' in str(e).lower():
            print(f"🚫 {group} banned")
        else:
            print(f"❌ Hata: {type(e).__name__}")
        return False

async def active_bot_mode():
    """Aktif bot modu - gerçek mesaj gönderme"""
    client = TelegramClient('immortal_session', api_id, api_hash)
    
    try:
        await client.connect()
        print("✅ AKTIF MODDA - MESAJ GÖNDERİMİ BAŞLADI!")
        
        cycle = 0
        banned = set()
        
        while running:
            cycle += 1
            print(f"\n🔄 ÇEVRİM #{cycle}")
            
            available = [g for g in target_groups if g not in banned]
            if not available:
                banned.clear()
                available = target_groups.copy()
            
            # 4 mesaj gönder
            for msg_num in range(1, 5):
                if not running: break
                
                message = 'Şov için müsaaitiimmmm ♥️'
                
                for group in available:
                    if not running: break
                    
                    success = await send_message_immortal(client, group, message)
                    if success:
                        print(f"✅ {msg_num}/4 → {group}")
                    else:
                        print(f"🚫 {msg_num}/4 → {group} (banned)")
                        banned.add(group)
                    
                    await asyncio.sleep(1)
                
                # Mesajlar arası bekleme
                if msg_num < 4 and running:
                    for i in range(4, 0, -1):
                        if not running: break
                        print(f"⏳ Sonraki mesaja {i}s...")
                        await asyncio.sleep(1)
            
            # Çevrim arası bekleme
            if running:
                for i in range(15, 0, -1):
                    if not running: break
                    if i % 5 == 0:
                        print(f"⏳ Sonraki çevrime {i}s...")
                    await asyncio.sleep(1)
                    
    except Exception as e:
        print(f"💥 Aktif mod hatası: {type(e).__name__}")
        return False
    finally:
        try:
            await client.disconnect()
        except:
            pass
    
    return True

async def waiting_mode():
    """Bekleme modu - authentication bekleniyor"""
    print("⏳ BEKLEME MODU - Authentication gerekli")
    print("📱 Authentication tamamlamak için:")
    print("   1. python src/enter_code.py")
    print("   2. Telefonunuza gelen kodu girin")
    print("   3. Bot otomatik aktif moda geçecek")
    
    check_interval = 30  # 30 saniye
    
    while running:
        print(f"\n🔄 Auth kontrol yapılıyor...")
        
        # Authentication kontrol et
        if await check_auth_status():
            print("🎉 Authentication başarılı! Aktif moda geçiliyor...")
            return await active_bot_mode()
        
        print(f"⏳ Authentication bekleniyor... ({check_interval}s sonra tekrar kontrol)")
        
        # Bekleme
        for i in range(check_interval, 0, -1):
            if not running: break
            if i % 10 == 0:  # Her 10 saniyede göster
                print(f"⏳ {i}s sonra tekrar kontrol...")
            await asyncio.sleep(1)
    
    return True

async def immortal_cycle():
    """ÖLÜMSÜZ ÇEVRIM"""
    global restart_count
    restart_count += 1
    
    print(f"🔄 BAŞLATMA #{restart_count}")
    print(f"📡 Hedef gruplar: {', '.join(target_groups)}")
    
    # Auth durumunu kontrol et
    if await check_auth_status():
        return await active_bot_mode()
    else:
        return await waiting_mode()

def restart_guardian():
    """YENİDEN BAŞLATMA KORUYUCUSU"""
    print("🛡️ 7/24 koruyucu aktif - BOT ASLA DURMAZ!")
    
    while running:
        try:
            print("🔥 IMMORTAL BOT BAŞLIYOR...")
            result = asyncio.run(immortal_cycle())
            
            if not running:
                print("👋 Temiz çıkış")
                break
            
            print("🔄 Yeniden başlatılıyor...")
            time.sleep(3)
            
        except KeyboardInterrupt:
            print("\n🛑 DURDURULDU")
            break
        except Exception as e:
            print(f"💥 KRİTİK HATA: {e}")
            print("🔄 ACİL YENİDEN BAŞLATMA...")
            time.sleep(2)

if __name__ == '__main__':
    try:
        restart_guardian()
    except Exception as e:
        print(f"💥 TOTAL SYSTEM FAILURE: {e}")
        time.sleep(3)