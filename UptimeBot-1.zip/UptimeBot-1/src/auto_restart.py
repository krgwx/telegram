#!/usr/bin/env python3
"""
Auto-restart wrapper for the Telegram bot
This ensures the bot never stops running, even if it crashes
"""

import subprocess
import sys
import time
import signal
import os
import threading
import requests

print("🛡️ AUTO-RESTART GUARDIAN - FREE PLAN EDITION")
print("="*55)

def ping_self():
    """Ping workspace to prevent sleep (Free plan protection)"""
    try:
        # Get workspace URL from environment
        repl_url = os.environ.get('REPL_URL', '')
        if repl_url:
            response = requests.get(repl_url, timeout=10)
            if response.status_code == 200:
                print("🏓 Workspace ping successful - staying alive")
        else:
            print("🏓 Self-ping to prevent sleep")
    except Exception as e:
        print(f"🏓 Ping failed (normal): {e}")

def start_self_ping():
    """Start self-ping thread for Free accounts"""
    def ping_loop():
        while not shutdown_requested:
            ping_self()
            time.sleep(300)  # Ping every 5 minutes
    
    ping_thread = threading.Thread(target=ping_loop, daemon=True)
    ping_thread.start()
    print("🏓 Self-ping protection started (Free plan)")

# Start self-ping protection
start_self_ping()

# Global flag for clean shutdown
shutdown_requested = False

def signal_handler(signum, frame):
    global shutdown_requested
    print(f"\n🚨 Signal {signum} received - will shutdown after current bot process ends")
    shutdown_requested = True

# Register signal handlers
signal.signal(signal.SIGTERM, signal_handler)
signal.signal(signal.SIGINT, signal_handler)

def run_bot():
    """Run the bot and return the exit code"""
    try:
        print("🚀 Starting Telegram bot...")
        result = subprocess.run([
            sys.executable, 
            'src/secure_telegram_bot.py'
        ], 
        capture_output=False,  # Allow terminal interaction
        text=True
        )
        return result.returncode
    except Exception as e:
        print(f"💥 Failed to start bot: {e}")
        return 1

def main():
    """Main auto-restart loop"""
    restart_count = 0
    
    while not shutdown_requested:
        restart_count += 1
        print(f"\n🔄 BOT RESTART #{restart_count}")
        
        # Run the bot
        exit_code = run_bot()
        
        if shutdown_requested:
            print("🛑 Shutdown requested - exiting")
            break
            
        if exit_code == 0:
            print("✅ Bot exited normally")
        else:
            print(f"❌ Bot crashed with exit code: {exit_code}")
        
        if not shutdown_requested:
            print("⏳ Waiting 3 seconds before restart...")
            for i in range(3, 0, -1):
                if shutdown_requested:
                    break
                print(f"⏰ Restarting in {i} seconds...")
                time.sleep(1)
    
    print("👋 Auto-restart guardian shutdown complete")

if __name__ == '__main__':
    try:
        main()
    except KeyboardInterrupt:
        print("\n🛑 Interrupted by user")
    except Exception as e:
        print(f"💥 Guardian crashed: {e}")
        # Try to restart the guardian itself
        print("🔄 Restarting guardian...")
        subprocess.run([sys.executable, __file__])